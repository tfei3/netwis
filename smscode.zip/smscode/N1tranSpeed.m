data=load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/simulationResult/1node-speed.dat');
x2=data(:,2)-446;
y2=data(:,6);
stairs(x2,y2)
