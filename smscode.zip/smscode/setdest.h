#ifndef __setdest_h__
#define __setdest_h__

/*#include <sys/queue.h>*/
#include "../../../config.h"
#include "../../../lib/bsd-list.h"

#ifndef LIST_FIRST
#define LIST_FIRST(head)	((head)->lh_first)
#endif
#ifndef LIST_NEXT
#define LIST_NEXT(elm, field)	((elm)->field.le_next)
#endif

void ReadInMovementPattern(void);

class vector {
public:
	vector(double x = 0.0, double y = 0.0, double z = 0.0) {
		X = x; Y = y; Z = z;
	}
	double length() {
		return sqrt(X*X + Y*Y + Z*Z);
	}

	inline void vector::operator=(const vector a) {
		X = a.X;
		Y = a.Y;
		Z = a.Z;
	}
	inline void vector::operator+=(const vector a) {
		X += a.X;
		Y += a.Y;
		Z += a.Z;
	}
	inline int vector::operator==(const vector a) {
		return (X == a.X && Y == a.Y && Z == a.Z);
	}
	inline int vector::operator!=(const vector a) {
		return (X != a.X || Y != a.Y || Z != a.Z);
	}
	inline vector operator-(const vector a) {
		return vector(X-a.X, Y-a.Y, Z-a.Z);
	}
	friend inline vector operator*(const double a, const vector b) {
		return vector(a*b.X, a*b.Y, a*b.Z);
	}
	friend inline vector operator/(const vector a, const double b) {
		return vector(a.X/b, a.Y/b, a.Z/b);
	}

	double X;
	double Y;
	double Z;
};


class Neighbor {
public:
	u_int32_t	index;			// index into NodeList
	u_int32_t	reachable;		// != 0 --> reachable.
	double		time_transition;	// next change

};

struct setdest {
  double time;
  double X, Y, Z;
  double speed;
  LIST_ENTRY(setdest)   traj;
};


// phase struct for sms model

struct phase {

   u_int32_t   status;     // current phase
   u_int32_t   step;       // current step at the corresponding phase
};


class Node {
  friend void ReadInMovementPattern(void);
public:
	Node(void);
	void	Update(void);
	void	UpdateNeighbors(void);
	void	Dump(void);

	double		time_arrival;		// time of arrival at dest
	double		time_transition;	// min of all neighbor times

	// # of optimal route changes for this node
	int		route_changes;
    int     link_changes;

private:

    vector  BorderEffect( vector p);    // add by ming zhao

	void	RandomPosition(void);
	void	RandomDestination(void);
	void	RandomSpeed(void);

	u_int32_t	index;                  // unique node identifier
	u_int32_t 	first_trip;		// 1 if first trip, 0 otherwise. (by J. Yoon)
   // u_int32_t   phase_status   // determine current phase of the movement (by, M. zhao)


    struct phase smsphase;

	vector		position;		// current position
	vector		destination;		// destination
	vector		direction;		// computed from pos and dest

	double		speed;
	double		time_update;		// when pos last updated

    u_int32_t   alpha;
    u_int32_t   beta;
    u_int32_t   gamma;
    u_int32_t   Initial_state;     // determine the initial state (1: Steady_state, 0: starts from alpha phase).
                                      // By default, the simulation runs from steady_state directly.  

    double      Step_direction ;     // moving direction of each step
    double      V_alpha ;          // Target speed V_alpha at alpha phase
    double      PHI_alpha ;        // Target direction Phi_alpha at alpha phase
    double      At_alpha ;         // acceleration in alpha phase

    double      PHI_beta ;         // Ending direction Phi_beta at beta phase
    double      V_beta ;           // Ending speed V_beta at beta phase

    double      PHI_gamma ;        // direction Phi_gamma at beta phase
    double      At_gamma ;         // deceleration in gamma phase



//double      V_GM = 0.0;             // Gauss Random Variable for speed in beta phase
//double      PHI_GM = 0.0;           // Gauss Random Variable for direction in beta phase
//double      PHI_ALPHA = 0.0;        // Target direction Phi_alpha at alpha phase
  //double      PHI_BETA = 0.0;         // Ending direction Phi_beta at beta phase
//double      V_BETA = 0.0;           // Ending speed V_beta at beta phase
//double      PHI_GAMMA = 0.0;        // direction Phi_gamma at beta phase



	static u_int32_t NodeIndex;

	LIST_HEAD(traj, setdest) traj;

public:
	// An array of NODES neighbors.
	Neighbor	*neighbor;
};

#endif /* __setdest_h__ */
