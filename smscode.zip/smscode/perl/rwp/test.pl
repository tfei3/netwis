$infile=$ARGV[0];                                                                    
open (DATA,"<$infile") || die "Can't open $infile $!\n";                                                                                                                           
while (<DATA>){
    @x = split(' ');
 
       $x[3] =~ s/\(//;
       $x[3] =~ s/\,//;
       
       $x[4] =~ s/\,//;

       $x[5] =~ s/\)\,//;       
  
       $x[6] =~ s/\(//;
       $x[6] =~ s/\,//;

       $x[7] =~ s/\)\,//;  

    if ($x[1] != 0.00000)
       
     {print "$x[2] $x[1] $x[3] $x[4] $x[6] $x[7] $x[8]\n";        
    
     }
                                                                                                                         
}                                                                                                                          
close (DATA);
exit(0);


