$infile=$ARGV[0];                                                                    
open (DATA,"<$infile") || die "Can't open $infile $!\n";                                                                                                                           
while (<DATA>){
    @x = split(' ');
    if ( ($x[1] eq 'set') && ($x[2] eq 'X_') ){
       $x[0] =~ s/\$node\_\(//;
       $x[0] =~ s/\)//;
       print "$x[0] 0.0 $x[3] ";
       }
    if ( ($x[1] eq 'set') && ($x[2] eq 'Y_') ){
       print "$x[3] 0.0\n";
       }     
    if ( ($x[0] eq '$ns_') && ($x[1] eq 'at') && ($x[3] ne '"$god_') ){
       $x[3] =~ s/\"\$node\_\(//;
       $x[3] =~ s/\)//;
       $x[7] =~ s/\"//;
       print "$x[3] $x[2] $x[5] $x[6] $x[7]\n";        
       }                                                                                                                         
}                                                                                                                          
close (DATA);
exit(0);
