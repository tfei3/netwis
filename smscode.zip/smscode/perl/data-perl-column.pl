$infile=$ARGV[0];                                                                    
open (DATA,"<$infile") || die "Can't open $infile $!\n";                                                                                                                           
while (<DATA>){
    @x = split(' ');
    
    if ( ($x[0] eq '$ns_') && ($x[1] eq 'at') && ($x[3] ne '"$god_') ){
       #$x[14] =~ s/\"\$node\_\(//;
       #$x[3] =~ s/\)//;
       $x[14] =~ s/\"//;
       print "$x[2] $x[10] $x[12] $x[13] $x[14]\n";        
       }    
    
  }                                                                                                                          
close (DATA);
exit(0);  
    
