$infile=$ARGV[0];                                                                    
open (DATA,"<$infile") || die "Can't open $infile $!\n";                                                                                                                           
while (<DATA>){
    @x = split(' ');
    
    if ( $x[2] eq '999.000000000000') {
      $x[3] =~ s/\"\$node\_\(//;
       $x[3] =~ s/\)//;
       print " $x[3] $x[12] $x[13] \n";        
       }    
    
  }                                                                                                                          
close (DATA);
exit(0);  
    
