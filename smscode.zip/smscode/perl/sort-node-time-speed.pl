$infile=$ARGV[0];                                                                    


#print "$s2\n";

open (DATA,"<$infile") || die "Can't open $infile $!\n";                                                                                                                           

while (<DATA>){
    $y="$_";
    @x = split(' ');
  
     print " $x[0] $x[1] $x[5]\n";        
                                                                                                                             
}
                                                                         
close (DATA);

exit(0);
