$infile=$ARGV[0];                                                                    


for( $i=50;$i<=99;$i++)
{

open (DATA,"<$infile") || die "Can't open $infile $!\n";                                                                                                                           

while (<DATA>){
    $y="$_";
    @x = split(' ');
    
    if ( ($x[0] eq $i) ){
      
       print " $x[0] $x[1] $x[2] \n";        
       }    
    
    
    
    
    #if ( ($x[0] eq $s2) || ($x[3] eq $s3) ){
                                                                                                                             
}

                        #@y1=split(' ',$s4);
		        #@y2=split(' ',$s5);
                        #$y1[3] =~ s/\"\$node\_\(//;
        		#$y1[3] =~ s/\)//;
        		#$y1[7] =~ s/\"//;
			#$y2[3] =~ s/\"\$node\_\(//;
        		#$y2[3] =~ s/\)//;
        		#$y2[7] =~ s/\"//;
			#$x5 =  ($y2[7] * cos (atan2( ($y2[6]-$y1[6]), ($y2[5]-$y1[5]) )) * (5000-$y2[2] ) ) + $y1[5]			#$y5 =  ($y2[7] * sin (atan2( ($y2[6]-$y1[6]), ($y2[5]-$y1[5]) )) * (5000-$y2[2] ) ) + $y1[6];
			#print "$y2[3] 5000 $x5 $y5 $y2[7]\n";
                                                                                                             
close (DATA);
}
exit(0);
