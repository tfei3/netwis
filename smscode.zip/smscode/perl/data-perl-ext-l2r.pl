$infile=$ARGV[0];                                                                    
open (DATA,"<$infile") || die "Can't open $infile $!\n";                                                                                                                           
$c=0;
while (<DATA>){
$c = $c + 1;
    @x = split(' ');
    if( $c == 1){
    $s1="$_";
    }
    else{
    if ( ($x[1] eq 'set') && ($x[2] eq 'X_') ){
        @y1=split(' ',$s1);
	$y1[3] =~ s/\"\$node\_\(//;
        $y1[3] =~ s/\)//;
        $y1[7] =~ s/\"//;
        print "$y1[3] $y1[2] $y1[5] $y1[6] $y1[7]\n";
	@y2=split(' ',$s2);
	$y2[3] =~ s/\"\$node\_\(//;
        $y2[3] =~ s/\)//;
        $y2[7] =~ s/\"//;
        print "$y2[3] $y2[2] $y2[5] $y2[6] $y2[7]\n";        
       }
       else {
        $s1=$s2;
        $s2="$_";
      }
    }                                                                                                                                 
}
	@y1=split(' ',$s1);
	$y1[3] =~ s/\"\$node\_\(//;
        $y1[3] =~ s/\)//;
        $y1[7] =~ s/\"//;
        print "$y1[3] $y1[2] $y1[5] $y1[6] $y1[7]\n";
	@y2=split(' ',$s2);
	$y2[3] =~ s/\"\$node\_\(//;
        $y2[3] =~ s/\)//;
        $y2[7] =~ s/\"//;
        print "$y2[3] $y2[2] $y2[5] $y2[6] $y2[7]\n";		                                                                                                                  
close (DATA);
exit(0);
