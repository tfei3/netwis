data=load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/simulationResult/node1traj.dat');
threshold = 500;
MaxX = 1500;
MaxY = 1500;
MinX = 0;
MinY = 0;
PI = 3.1415926;
% used to seperate the different boder point
breakPosition = [];


  % find out the length of the matrix.
  sort_length =length(data(:,1));
  % d is the direction column  
   d = data(:,3);
   x = data(:,4);
   y = data(:,5);
   
   
   
 for i = 1: sort_length-1
  % column 4 is the x position  
       if ( abs( x(i+1) - x(i) ) > threshold  | abs( y(i+1) -y(i)) > threshold)       
       %   data(i,1) close to MaxX
         breakPosition = [breakPosition, i];   
         
       end
 
 end
    
 break_No = length(breakPosition);
 
 if (break_No == 0) 
     plot (x,y,'r') 
      
 else    
      for i = 1 : break_No
          
        if (i == 1)
          plot ( x(1:breakPosition(1)),y(1:breakPosition(1)));
          hold on
        else
          plot ( x(breakPosition(i-1)+1 : breakPosition(i)), y(breakPosition(i-1)+1 : breakPosition(i))); 
          hold on  
        end        
       
        plot ( x(breakPosition(break_No)+1 : end), y(breakPosition(break_No)+1 : end) );
      end   
 
 end 
 
for i = 1 : break_No 
 
    if ( (x( breakPosition(i)) > x(breakPosition(i)+1)) && ((x( breakPosition(i)) - x(breakPosition(i)+1)) >  (y( breakPosition(i)) - y(breakPosition(i)+1))))  % break position is close to MaxX
              
        delta_x = MaxX - x(breakPosition(i));
        delta_y = tan(d(breakPosition(i)+1))* delta_x;
        edge_y = delta_y + y(breakPosition(i));                   
                
          if (edge_y > MaxY)
             delta_x = (MaxY-y( breakPosition(i)))/ abs(tan(d(breakPosition(i)+1)));
             
             delta_y = (MaxX- x( breakPosition(i)) -delta_x)* abs(tan(d(breakPosition(i)+1)));
              
             plot ( [x( breakPosition(i)), x( breakPosition(i)) + delta_x], [ y( breakPosition(i)), MaxY ]);
             
             plot(  [ x( breakPosition(i)) + delta_x , MaxX ], [ MinY, MinY+delta_y ]);
             
             plot (  [MinX, x( breakPosition(i)+1) ],  [MinY+ delta_y, y( breakPosition(i)+1)]);
         
          elseif (edge_y < MinY)   
                         
             delta_x = abs((y( breakPosition(i)) - MinY)/ tan(d(breakPosition(i)+1)) );
             
             delta_y = abs((MaxX-x( breakPosition(i))-delta_x)* tan(d(breakPosition(i)+1)));
             
             
             plot( [x( breakPosition(i)), x( breakPosition(i)) + delta_x], [ y( breakPosition(i)), MinY ] ) ;
             
             plot( [x( breakPosition(i)) + delta_x, MaxX ], [ MaxY, MaxY-delta_y ]);
             
             plot ( [MinX, x( breakPosition(i)+1) ],  [MaxY-delta_y, y( breakPosition(i)+1)]);
             
                           
          else              
                 plot( [x( breakPosition(i)), MaxX ], [y( breakPosition(i)), edge_y] );
                 
                 plot( [MinX, x( breakPosition(i)+1)], [edge_y, y( breakPosition(i)+1)] );
                     
                
          end
                  
   end   
 
    
    if ( (x( breakPosition(i)) < x(breakPosition(i)+1)) &&   ((x( breakPosition(i)+1) - x(breakPosition(i)) >  (y( breakPosition(i)) - y(breakPosition(i)+1)) ) ) )  % break position is close to MinX
              
        delta_x = x( breakPosition(i))- MinX ;
        beta = PI - d(breakPosition(i)+1);         
        delta_y = tan(beta)* delta_x;
        edge_y = delta_y + y (breakPosition(i));                   
                
          if (edge_y > MaxY)
             delta_x = abs((MaxY-y( breakPosition(i)))/ tan(beta));
             
             delta_y = ( x( breakPosition(i)) -delta_x - MinX) * tan(beta);
              
             plot ( [x( breakPosition(i)), x( breakPosition(i))-delta_x -MinX], [ y( breakPosition(i)), MaxY ]);
             
             plot(  [x( breakPosition(i))-delta_x - Minx, MinX ], [ MinY, MinY+ delta_y ]);
             
             plot (  [MaxX, x( breakPosition(i)+1) ],  [MinY+delta_y, y( breakPosition(i)+1)]);
         
          elseif (edge_y < MinY)   
                         
             delta_x = abs((y( breakPosition(i)) - MinY)/ tan(beta));
             
             delta_y = abs((x( breakPosition(i))-delta_x-MinX)* tan(beta));
             
             plot( [x( breakPosition(i)), x( breakPosition(i))-delta_x -MinX], [ y( breakPosition(i)), MinY ] ) ;
             
             plot( [x( breakPosition(i))-delta_x-MinX, MinX ], [ MaxY, MaxY-delta_y ]);
             
             plot ( [MaxX, x( breakPosition(i)+1) ],  [MaxY-delta_y, y( breakPosition(i)+1)]);
             
                           
          else              
                 plot( [x( breakPosition(i)), MinX ], [y( breakPosition(i)), edge_y] );
                 
                 plot( [MaxX, x( breakPosition(i)+1)], [edge_y, y( breakPosition(i)+1)] );                     
          end
                  
     end 
    
    
    if ( (y( breakPosition(i)) > y(breakPosition(i)+1)) && ((x( breakPosition(i)) - x(breakPosition(i)+1)) <  (y( breakPosition(i)) - y(breakPosition(i)+1))))  % break position is close to MaxY
              
        delta_y = MaxY - y(breakPosition(i));
        delta_x = delta_y /tan(d(breakPosition(i)+1));
        edge_x = delta_x + x(breakPosition(i));                   
                
          if (edge_x > MaxX)
             
              delta_y = ( MaxX - x( breakPosition(i)) - MinX) * abs(tan(d(breakPosition(i)+1)));
              delta_x = (MaxY - delta_y -y( breakPosition(i)) - MinY)/abs(tan(d(breakPosition(i)+1))) ;
              
             plot ( [x( breakPosition(i)), MaxX], [ y( breakPosition(i)),  MinY + y( breakPosition(i))+ delta_y]);
             
             plot(  [MinX, MinX+ delta_x ], [ MinY + y( breakPosition(i))+ delta_y, MaxY ]);
             
             plot (  [MinX+ delta_x, x( breakPosition(i)+1) ],  [MinY, y( breakPosition(i)+1)]);
         
          elseif (edge_x < MinX)   
                         
             
              delta_y = (x( breakPosition(i)) - MinX) *  tan(d(breakPosition(i)+1));
              
              delta_x = (MaxY - delta_y -y( breakPosition(i)) - MinY)/abs(tan(d(breakPosition(i)+1))) ;
              
             plot( [x( breakPosition(i)), MinX], [ y( breakPosition(i)), MaxY - delta_y -y( breakPosition(i)) ] ) ;
             
             plot( [MaxX, MaxX-delta_x ], [ MaxY - delta_y -y( breakPosition(i)), MaxY ]);
             
             plot ( [MaxX-delta_x , x( breakPosition(i)+1) ],  [MinY, y( breakPosition(i)+1)]);
             
                           
          else              
                 plot( [x( breakPosition(i)), edge_x ], [y( breakPosition(i)), MaxY] );
                 
                 plot( [edge_x, x( breakPosition(i)+1)], [MinY, y( breakPosition(i)+1)] );
                     
                
          end
                  
   end   
    
    
  if ( (y( breakPosition(i)) < y(breakPosition(i)+1)) & ((x( breakPosition(i)) - x(breakPosition(i)+1)) >  (y( breakPosition(i)+1) - y(breakPosition(i))))  )  % break position is close to MaxY
        
        beta = d(breakPosition(i)+1) - 3*PI/2;       
        delta_y = y(breakPosition(i)) - MinY;
        delta_x = delta_y /tan(beta);
        edge_x = delta_x + x(breakPosition(i));                   
                
          if (edge_x > MaxX)
             
              delta_y = ( MaxX - x( breakPosition(i)) - MinX) * abs(tan(beta));
              delta_x = (MaxY - delta_y -y( breakPosition(i)) - MinY)/abs(tan(beta)) ;
             plot ( [x( breakPosition(i)), MaxX], [ y( breakPosition(i)), MaxY - delta_y -y( breakPosition(i)) - MinY ]);
             
             plot(  [MinX, MinX+ delta_x ], [ MaxY - delta_y -y( breakPosition(i)) - MinY , MinY ]);
             
             plot (  [MinX+ delta_x, x( breakPosition(i)+1) ],  [MaxY, y( breakPosition(i)+1)]);
         
          elseif (edge_x < MinX)   
                         
              delta_y = (x( breakPosition(i)) - MinX) *  tan(beta);
              
              delta_x = (MaxY - delta_y -y( breakPosition(i)) - MinY)/abs(tan(beta)) ;
              
             plot( [x( breakPosition(i)), MinX], [ y( breakPosition(i)), MaxY - delta_y -y( breakPosition(i)) ] ) ;
             
             plot( [MaxX, MaxX-delta_x ], [ MaxY - delta_y -y( breakPosition(i)), MinY ]);
             
             plot ( [MaxX-delta_x , x( breakPosition(i)+1) ],  [MaxY, y( breakPosition(i)+1)]);
             
                           
          else              
                 plot( [x( breakPosition(i)), edge_x ], [y( breakPosition(i)), MinY] );
                 
                 plot( [edge_x, x( breakPosition(i)+1)], [MaxY, y( breakPosition(i)+1)] );
                     
                
          end
                  
   end     
    
end % end for loop     
hold on