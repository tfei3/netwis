data=load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/linkcode/rwp/rwp-n50-t1500-xy1401-p0-M20-v1-stand-trajout');
N=49; %total number of nodes could not be larger than 1000
TTime=1500; %total simulation time
SCALE=10;
S=TTime/SCALE;
%row_start(1)=1;
for i=1:N
    % get the end row position of node i-1
    % the start row position of node i is len(i)+1
    row_start(i)=length(find(data(:,1)<i));
    %eg. the start row position of node 1 is len(1)+1
end
temp=0;
% for node 0
pos=1;
for j=1:S
    startpos=1;
    endpos=row_start(1);
    %find the position of the time we want
    timepos=length(find(data(startpos:endpos,2)<=j*SCALE));
    %%%%%%%%% Average upon the time period
    if (startpos+timepos-pos ~= 0)
        temp=sum(data(pos:startpos+timepos-1,5))/(startpos+timepos-pos);
        %row_tp(1,j)=data(timepos,5);
        row_tp(1,j)=temp;
    else
        row_tp(1,j)=row_tp(1,j-1);
    end
    pos=startpos+timepos;
end

for i=1:N-1
    %row_tp nXN matrix ith row store the speed of ith node speed at different time  
    % columns store the different time scale, 100s, 200s,...4900s, 5000s 50
    temp=0;
    timpos=1;
    pos=row_start(i)+1;
    for j=1:S
        startpos=row_start(i)+1;
        endpos=row_start(i+1);
        timepos=length(find(data(startpos:endpos,2)<=j*SCALE));
        %%%%%%%%%%%%5 Average upon the time period
        if (startpos+timepos-pos ~= 0)
            temp=sum(data(pos:startpos+timepos-1,5))/(startpos+timepos-pos);
            %row_tp(i+1,j)=data(startpos+timepos-1, 5);
            row_tp(i+1,j)=temp;
        else
            row_tp(i+1,j)=row_tp(i+1,j-1);
        end
        pos=startpos+timepos;
    end
end
%calculate the average speed
for j=1:S
    avg_speed(j)=sum(row_tp(:,j))/(N+1);
end
for j=1:S
    time(j)=j*SCALE;
end
plot(time, avg_speed)
