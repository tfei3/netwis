data=load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/infocom06/data/OneMovementTraceLength3.dat')

SMS_time = length(data);
X = data(:,4);
Y = data(:,5);
V = data(:,6);

Trace_Length = [];
temp =0;

for i=1 : SMS_time-1
    
    temp = V(i) + temp;
    Trace_Length = [Trace_Length, temp];
end

Distance =[];

for i =1: SMS_time -1
    
    Distance(i) = sqrt( ( X(i+1) -X(1))^2  +  ( Y(i+1) -Y(1))^2  );
end

%Trace_Length = [0, Trace_Length];
%Distance = [ 0,  Distance];
    
plot (1 : SMS_time-1 , Trace_Length)
hold on
plot(1:SMS_time-1, Distance)
   