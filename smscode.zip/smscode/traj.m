hold off
data=load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/simulationResult/1node-traj7.dat');
%i=input('please input node index = ');
%x=find(data(:,1)==i);
X0=data(:,4);
Y0=data(:,5);
plot(X0,Y0,'r');

%title('Average Waiting Time in System M/G/1');
%xlabel('RHO=LAMBDA/MU');
%ylabel('Average Waiting Time in System');
%legend('M/G/1 Results','M/M/1 Results');

% hold off;
%rwpNodeDistribution_output