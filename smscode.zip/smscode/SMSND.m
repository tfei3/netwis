data=load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/simulationResult/v2-N1000-T5000-ns.plout');
X0=data(:,3);
Y0=data(:,4);

plot(X0,Y0,'r');

%title('Average Waiting Time in System M/G/1');
%xlabel('RHO=LAMBDA/MU');
%ylabel('Average Waiting Time in System');
%legend('M/G/1 Results','M/M/1 Results');

% hold off;
%rwpNodeDistribution_output