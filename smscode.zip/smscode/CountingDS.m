data = load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/simulationResult/v2-N1000-T5000-ns.plout');
A = data(:,3:4);
%A = sort(XY,1);
scale = 150 ;

m = 1500/scale;
% sumlen = 0;
for i = 1: m
   
  Xlen= find( A(:,1) > (i-1)*scale & A(:,1) <= i*scale);
 
   tempY= A(Xlen,2);
 
  % tempY = sort(tempY);
 
    for j = 1: m
     
    DS(i,j)= length(find(tempY <= j*scale & tempY > (j-1)*scale));
 
    end   
    
end    

DS
    
 