data=load('/local/ming/ns-allinone-2.27/ns-2.27/indep-utils/cmu-scen-gen/setdest/data/avgVsms-n200T1000matlab.dat');
N=100;
avgv= sum(data)/N;